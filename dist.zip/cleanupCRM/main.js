(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/CRM/Leads/lead-list/lead-list.component.html":
/*!**************************************************************!*\
  !*** ./src/app/CRM/Leads/lead-list/lead-list.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-chip-list>\r\n  <mat-chip (click)='allLeads()'>Все лиды</mat-chip>\r\n  <mat-chip (click)=\"todayTasks()\" color=\"accent\">Дела на сегодня</mat-chip>\r\n  <mat-chip (click)=\"overDateTasks()\" color=\"primary\" selected>Просроченные дела</mat-chip>\r\n</mat-chip-list>\r\n<div class=\"container\">\r\n  <div class=\"row\">\r\n    <div class=\"col-12\">\r\n        <mat-form-field>\r\n            <input matInput (keyup)=\"applyFilter($event.target.value)\" placeholder=\"Поиск лида\">\r\n          </mat-form-field>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"container\">\r\n  <div class=\"row\">\r\n    <div class=\"col-12\">\r\n      <table mat-table [dataSource]=\"dataSource\" matSort class=\"mat-elevation-z8\">\r\n\r\n        <ng-container matColumnDef=\"firmName\">\r\n          <th mat-header-cell *matHeaderCellDef mat-sort-header> Название </th>\r\n          <td mat-cell *matCellDef=\"let element\"> \r\n              <a target=\"_blank\" routerLink=\"{{element.leadId}}\">\r\n                  {{element.firmName}}\r\n              </a>\r\n          </td>\r\n        </ng-container>\r\n      \r\n        <ng-container matColumnDef=\"tasks\">\r\n          <th mat-header-cell *matHeaderCellDef mat-sort-header> Задачи </th>\r\n          <td mat-cell *matCellDef=\"let element\">\r\n            <div *ngFor=\"let x of element.tasks\"> \r\n              <span *ngIf='x.status==\"started\"'>{{x.deadLineDate | date: 'dd.MM.yyyy'}}</span> \r\n              <br *ngIf='x.status==\"started\"'>\r\n              <span *ngIf='x.status==\"started\"'>{{x.deadLineDate | date: 'HH:mm'}}</span>\r\n            </div> \r\n          </td>\r\n        </ng-container>\r\n      \r\n        <ng-container matColumnDef=\"address\">\r\n          <th mat-header-cell *matHeaderCellDef mat-sort-header> Адрес </th>\r\n          <td mat-cell *matCellDef=\"let element\"> {{element.address}} </td>\r\n        </ng-container>\r\n      \r\n        <ng-container matColumnDef=\"createdDate\">\r\n          <th mat-header-cell *matHeaderCellDef mat-sort-header> Дата создания </th>\r\n          <td mat-cell *matCellDef=\"let element\"> {{element.createdDate | date: 'dd.MM.yyyy'}} </td>\r\n        </ng-container>\r\n      \r\n        <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\r\n        <tr mat-row *matRowDef=\"let row; columns: displayedColumns;\"></tr>\r\n        \r\n      </table>\r\n      <mat-paginator [pageSize]=\"10\"  [pageSizeOptions]=\"[5, 10, 20]\"></mat-paginator>\r\n    </div>\r\n  </div>\r\n</div>"

/***/ }),

/***/ "./src/app/CRM/Leads/lead-list/lead-list.component.styl":
/*!**************************************************************!*\
  !*** ./src/app/CRM/Leads/lead-list/lead-list.component.styl ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "table {\n  width: 100%;\n}\n/*# sourceMappingURL=src/app/CRM/Leads/lead-list/lead-list.component.css.map */\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvQ1JNL0xlYWRzL2xlYWQtbGlzdC9zcmMvYXBwL0NSTS9MZWFkcy9sZWFkLWxpc3QvbGVhZC1saXN0LmNvbXBvbmVudC5zdHlsIiwic3JjL2FwcC9DUk0vTGVhZHMvbGVhZC1saXN0L2xlYWQtbGlzdC5jb21wb25lbnQuc3R5bCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQU87QUNDVDtBQUNBLDhFQUE4RSIsImZpbGUiOiJzcmMvYXBwL0NSTS9MZWFkcy9sZWFkLWxpc3QvbGVhZC1saXN0LmNvbXBvbmVudC5zdHlsIiwic291cmNlc0NvbnRlbnQiOlsidGFibGUge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59IiwidGFibGUge1xuICB3aWR0aDogMTAwJTtcbn1cbi8qIyBzb3VyY2VNYXBwaW5nVVJMPXNyYy9hcHAvQ1JNL0xlYWRzL2xlYWQtbGlzdC9sZWFkLWxpc3QuY29tcG9uZW50LmNzcy5tYXAgKi8iXX0= */"

/***/ }),

/***/ "./src/app/CRM/Leads/lead-list/lead-list.component.ts":
/*!************************************************************!*\
  !*** ./src/app/CRM/Leads/lead-list/lead-list.component.ts ***!
  \************************************************************/
/*! exports provided: LeadListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LeadListComponent", function() { return LeadListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var src_app_services_HTTP_myhttp_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/HTTP/myhttp.service */ "./src/app/services/HTTP/myhttp.service.ts");




var LeadListComponent = /** @class */ (function () {
    function LeadListComponent(myHttp) {
        this.myHttp = myHttp;
        this.displayedColumns = ['firmName', 'tasks', 'address', 'createdDate'];
    }
    LeadListComponent.prototype.ngOnInit = function () {
        this.getLeadList();
    };
    LeadListComponent.prototype.getLeadList = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.myHttp.getHTTP('http://localhost:3000/getLeadList')
                            .subscribe(function (data) {
                            _this.Leads = data;
                            _this.refreshDataSource(_this.Leads);
                            return;
                        }, function (err) {
                            console.log('Get all Leads error: ' + err);
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ;
    LeadListComponent.prototype.refreshDataSource = function (data) {
        this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
    };
    LeadListComponent.prototype.applyFilter = function (filterValue) {
        this.dataSource.filter = filterValue.trim().toLowerCase();
    };
    LeadListComponent.prototype.todayTasks = function () {
        var today = new Date, tomorrow = new Date, array = [];
        today = this.nulledDay(today);
        tomorrow = this.nulledDay(tomorrow);
        tomorrow.setDate(tomorrow.getDate() + 1);
        var newToday = Date.parse(today.toISOString()), newTomorrow = Date.parse(tomorrow.toISOString());
        var deadLine;
        for (var _i = 0, _a = this.Leads; _i < _a.length; _i++) {
            var x = _a[_i];
            for (var _b = 0, _c = x.tasks; _b < _c.length; _b++) {
                var y = _c[_b];
                deadLine = Date.parse(y.deadLineDate.toString());
                if (y.status === 'started' && deadLine > newToday && deadLine < newTomorrow) {
                    array.push(x);
                }
            }
        }
        this.refreshDataSource(array);
    };
    LeadListComponent.prototype.overDateTasks = function () {
        var today = new Date, array = [];
        today = this.nulledDay(today);
        var newToday = Date.parse(today.toISOString());
        var deadLine;
        for (var _i = 0, _a = this.Leads; _i < _a.length; _i++) {
            var x = _a[_i];
            for (var _b = 0, _c = x.tasks; _b < _c.length; _b++) {
                var y = _c[_b];
                deadLine = Date.parse(y.deadLineDate.toString());
                if (y.status === 'started' && deadLine < newToday) {
                    array.push(x);
                }
            }
        }
        this.refreshDataSource(array);
    };
    LeadListComponent.prototype.allLeads = function () {
        this.refreshDataSource(this.Leads);
    };
    LeadListComponent.prototype.nulledDay = function (day) {
        day.setHours(0);
        day.setMinutes(0);
        day.setSeconds(0);
        day.setMilliseconds(0);
        return day;
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSort"]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSort"])
    ], LeadListComponent.prototype, "sort", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material__WEBPACK_IMPORTED_MODULE_2__["MatPaginator"]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatPaginator"])
    ], LeadListComponent.prototype, "paginator", void 0);
    LeadListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-lead-list',
            template: __webpack_require__(/*! ./lead-list.component.html */ "./src/app/CRM/Leads/lead-list/lead-list.component.html"),
            styles: [__webpack_require__(/*! ./lead-list.component.styl */ "./src/app/CRM/Leads/lead-list/lead-list.component.styl")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_HTTP_myhttp_service__WEBPACK_IMPORTED_MODULE_3__["myHTTPService"]])
    ], LeadListComponent);
    return LeadListComponent;
}());



/***/ }),

/***/ "./src/app/CRM/Leads/lead-page/lead-page.component.html":
/*!**************************************************************!*\
  !*** ./src/app/CRM/Leads/lead-page/lead-page.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section>\r\n    <div class=\"container\">\r\n        <div class=\"row\">\r\n            <div class=\"col-4\">\r\n                <div class=\"wrapp\">\r\n                    <a href=\"#\" class='change-lead' (click)='preChangeLead($event, true)'>Изменить Лид</a>\r\n                    <div class=\"row\">\r\n                        <div class=\"col-12\">\r\n                            <h1 *ngIf='!changeIndicator'>{{Lead.firmName}}</h1>\r\n                            <mat-form-field *ngIf='changeIndicator'>\r\n                                <input matInput placeholder=\"Название фирмы\" [(ngModel)]='Lead.firmName'>\r\n                            </mat-form-field>\r\n                                \r\n                        </div>\r\n                        <div class=\"col-12\">\r\n                            <mat-form-field>\r\n                                <mat-select placeholder=\"Статус\" (selectionChange)=\"changeLeadStatus ()\" [(ngModel)]='Lead.leadStatus'>\r\n                                    <mat-option *ngFor=\"let x of LeadStatus;\" [value]=\"x.status\">\r\n                                        {{x.translate}}\r\n                                    </mat-option>\r\n                                </mat-select>\r\n                            </mat-form-field>\r\n                        </div>\r\n                        <div class=\"col-12\" *ngFor=\"let x of Lead.contactPhones; index as i\">\r\n                            <a *ngIf='!changeIndicator' href='callto:{{x}}' title=\"{{x}}\">{{x}}</a>\r\n                            <mat-form-field *ngIf='changeIndicator'>\r\n                                <input matInput placeholder=\"Номер телефона\" [(ngModel)]='Lead.contactPhones[i]'>\r\n                            </mat-form-field>\r\n                        </div>\r\n                        <div class=\"col-12\">\r\n                            <a href=\"#\" *ngIf='changeIndicator' (click)='addNewPhone($event)'>Добавить номер</a>\r\n                        </div>\r\n                        <div class=\"col-12\">\r\n                            <a *ngIf='!changeIndicator' href=\"mailto:{{Lead.contactEmail}}\">{{Lead.contactEmail}}</a>\r\n                            <mat-form-field *ngIf='changeIndicator'>\r\n                                <input matInput placeholder=\"Контактный email\" [(ngModel)]='Lead.contactEmail'>\r\n                            </mat-form-field>\r\n                        </div>\r\n                        <div class=\"col-12\">\r\n                            <p *ngIf='!changeIndicator'>{{Lead.address}}</p>\r\n                            <mat-form-field *ngIf='changeIndicator'>\r\n                                <input matInput placeholder=\"Адрес\" [(ngModel)]='Lead.address'>\r\n                            </mat-form-field>\r\n                        </div>\r\n                        <div class=\"col-12\">\r\n                            <p *ngIf=\"Lead.contactName && !changeIndicator\">Имя собеседника: {{Lead.contactName}}</p>\r\n                            <mat-form-field *ngIf='changeIndicator'>\r\n                                <input matInput placeholder=\"Имя собеседника\" [(ngModel)]='Lead.contactName'>\r\n                            </mat-form-field>\r\n                        </div>\r\n                        <div class=\"col-12\">\r\n                            <p *ngIf=\"Lead.position && !changeIndicator\">Должность: {{Lead.position}}</p>\r\n                            <mat-form-field *ngIf='changeIndicator'>\r\n                                <input matInput placeholder=\"Должность\" [(ngModel)]='Lead.position'>\r\n                            </mat-form-field>\r\n                        </div>\r\n                        <div class=\"col-12\">\r\n                            <p *ngIf=\"Lead.lprsName && !changeIndicator\">Имя ЛПР: {{Lead.lprsName}}</p>\r\n                            <mat-form-field *ngIf='changeIndicator'>\r\n                                <input matInput placeholder=\"Имя ЛПР\" [(ngModel)]='Lead.lprsName'>\r\n                            </mat-form-field>\r\n                        </div>\r\n                        <div class=\"col-12\">\r\n                            <button mat-raised-button color=\"primary\" *ngIf='changeIndicator' (click)='saveLeadChanges()'>Сохранить</button>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <button mat-raised-button (click)=\"openDialog()\">Предложения</button>\r\n            </div>\r\n            <div class=\"col-5\">\r\n                <div class=\"wrapp\" [formGroup]=\"taskDesk\">\r\n                    <mat-form-field>\r\n                        <mat-select placeholder=\"Задача\" formControlName=\"actions\">\r\n                            <mat-option *ngFor=\"let x of taskPanelControl;\" [value]=\"x.action\">\r\n                            {{x.translate}}\r\n                            </mat-option>\r\n                        </mat-select>\r\n                    </mat-form-field>\r\n\r\n            \r\n                    <div class=\"w-100\">\r\n                        <mat-form-field style=\"width: 100%;\">\r\n                            <textarea matInput formControlName=\"description\" placeholder=\"Описание задачи\"></textarea>\r\n                        </mat-form-field>\r\n                    </div>\r\n            \r\n                    <div class=\"w-100\" *ngIf='taskDesk.get(\"actions\").value != \"comment\"'>\r\n                        <mat-form-field>\r\n                            <input matInput formControlName=\"deadLineDate\" [owlDateTime]=\"dt1\" [owlDateTimeTrigger]=\"dt1\" placeholder=\"Дата задачи\">\r\n                            <owl-date-time #dt1></owl-date-time>\r\n                        </mat-form-field>\r\n                    </div>\r\n                    <button mat-raised-button color=\"primary\" (click)='createNewTask()'>Сохранить</button>\r\n                </div>\r\n                <div class=\"wrapp\" *ngFor='let x of TaskDesk'>\r\n                    <div *ngFor=\"let y of PanelControl\">\r\n                        <mat-checkbox *ngIf='y.action === x.action && x.status === \"started\"'  (click)='changeTaskStatus(x)'>\r\n                            {{y.translate}}\r\n                            <span class='deadline-date' *ngIf='x.deadLineDate'> {{x.deadLineDate | date: 'dd.MM.yyyy HH:mm'}}</span>\r\n                        </mat-checkbox>\r\n                    </div>\r\n                    <span *ngIf=\"x.finishedDate\">{{x.finishedDate | date: 'dd.MM.yyyy HH:mm'}}</span>\r\n                    <p>{{x.description}}</p>\r\n                    <span class='created-date'>Дата создания: {{x.createdDate | date: 'dd.MM.yyyy HH:mm'}}</span>\r\n                </div>\r\n                    \r\n            </div>\r\n        </div> \r\n    </div>\r\n</section>"

/***/ }),

/***/ "./src/app/CRM/Leads/lead-page/lead-page.component.styl":
/*!**************************************************************!*\
  !*** ./src/app/CRM/Leads/lead-page/lead-page.component.styl ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".wrapp {\n  position: relative;\n  background-color: #fff;\n  margin-bottom: 1rem;\n  box-shadow: 0 1px 1px 0 rgba(0,0,0,0.04);\n  padding: 20px;\n  border-radius: 10px;\n}\n.wrapp .change-lead {\n  position: absolute;\n  right: 10px;\n  top: 10px;\n}\n.wrapp .created-date {\n  position: absolute;\n  font-size: 0.7rem;\n  right: 20px;\n}\n.wrapp .deadline-date {\n  font-size: 0.8rem !important;\n  padding-left: 10px;\n}\n.wrapp p {\n  margin-bottom: 0;\n}\n/*# sourceMappingURL=src/app/CRM/Leads/lead-page/lead-page.component.css.map */\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvQ1JNL0xlYWRzL2xlYWQtcGFnZS9zcmMvYXBwL0NSTS9MZWFkcy9sZWFkLXBhZ2UvbGVhZC1wYWdlLmNvbXBvbmVudC5zdHlsIiwic3JjL2FwcC9DUk0vTGVhZHMvbGVhZC1wYWdlL2xlYWQtcGFnZS5jb21wb25lbnQuc3R5bCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtCQUFTO0VBQ1Qsc0JBQWlCO0VBQ2pCLG1CQUFjO0VBQ2Qsd0NBQVk7RUFDWixhQUFRO0VBQ1IsbUJBQWU7QUNDbkI7QURBSTtFQUNJLGtCQUFTO0VBQ1QsV0FBTTtFQUNOLFNBQUk7QUNFWjtBRERJO0VBQ0ksa0JBQVM7RUFDVCxpQkFBVztFQUNYLFdBQU07QUNHZDtBREZJO0VBQ0ksNEJBQVc7RUFDWCxrQkFBYTtBQ0lyQjtBREhJO0VBQ0ksZ0JBQWM7QUNLdEI7QUFDQSw4RUFBOEUiLCJmaWxlIjoic3JjL2FwcC9DUk0vTGVhZHMvbGVhZC1wYWdlL2xlYWQtcGFnZS5jb21wb25lbnQuc3R5bCIsInNvdXJjZXNDb250ZW50IjpbIi53cmFwcFxyXG4gICAgcG9zaXRpb24gcmVsYXRpdmVcclxuICAgIGJhY2tncm91bmQtY29sb3Igd2hpdGVcclxuICAgIG1hcmdpbi1ib3R0b20gMXJlbVxyXG4gICAgYm94LXNoYWRvdzogMCAxcHggMXB4IDAgcmdiYSgwLDAsMCwuMDQpO1xyXG4gICAgcGFkZGluZyAyMHB4XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4XHJcbiAgICAmIC5jaGFuZ2UtbGVhZFxyXG4gICAgICAgIHBvc2l0aW9uIGFic29sdXRlXHJcbiAgICAgICAgcmlnaHQgMTBweFxyXG4gICAgICAgIHRvcCAxMHB4XHJcbiAgICAmIC5jcmVhdGVkLWRhdGUgXHJcbiAgICAgICAgcG9zaXRpb24gYWJzb2x1dGVcclxuICAgICAgICBmb250LXNpemU6IC43cmVtXHJcbiAgICAgICAgcmlnaHQgMjBweFxyXG4gICAgJiAuZGVhZGxpbmUtZGF0ZVxyXG4gICAgICAgIGZvbnQtc2l6ZTogLjhyZW0haW1wb3J0YW50XHJcbiAgICAgICAgcGFkZGluZy1sZWZ0IDEwcHhcclxuICAgICYgcFxyXG4gICAgICAgIG1hcmdpbi1ib3R0b20gMFxyXG4iLCIud3JhcHAge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gIG1hcmdpbi1ib3R0b206IDFyZW07XG4gIGJveC1zaGFkb3c6IDAgMXB4IDFweCAwIHJnYmEoMCwwLDAsMC4wNCk7XG4gIHBhZGRpbmc6IDIwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG4ud3JhcHAgLmNoYW5nZS1sZWFkIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogMTBweDtcbiAgdG9wOiAxMHB4O1xufVxuLndyYXBwIC5jcmVhdGVkLWRhdGUge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGZvbnQtc2l6ZTogMC43cmVtO1xuICByaWdodDogMjBweDtcbn1cbi53cmFwcCAuZGVhZGxpbmUtZGF0ZSB7XG4gIGZvbnQtc2l6ZTogMC44cmVtICFpbXBvcnRhbnQ7XG4gIHBhZGRpbmctbGVmdDogMTBweDtcbn1cbi53cmFwcCBwIHtcbiAgbWFyZ2luLWJvdHRvbTogMDtcbn1cbi8qIyBzb3VyY2VNYXBwaW5nVVJMPXNyYy9hcHAvQ1JNL0xlYWRzL2xlYWQtcGFnZS9sZWFkLXBhZ2UuY29tcG9uZW50LmNzcy5tYXAgKi8iXX0= */"

/***/ }),

/***/ "./src/app/CRM/Leads/lead-page/lead-page.component.ts":
/*!************************************************************!*\
  !*** ./src/app/CRM/Leads/lead-page/lead-page.component.ts ***!
  \************************************************************/
/*! exports provided: LeadPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LeadPageComponent", function() { return LeadPageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_services_HTTP_myhttp_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/HTTP/myhttp.service */ "./src/app/services/HTTP/myhttp.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _Offers_offer_into_lead_offer_into_lead_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../Offers/offer-into-lead/offer-into-lead.component */ "./src/app/CRM/Offers/offer-into-lead/offer-into-lead.component.ts");
/* harmony import */ var src_app_services_alert_alert_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/alert/alert.service */ "./src/app/services/alert/alert.service.ts");








var LeadPageComponent = /** @class */ (function () {
    function LeadPageComponent(alert, route, myHttp, fb, dialog) {
        var _this = this;
        this.alert = alert;
        this.route = route;
        this.myHttp = myHttp;
        this.fb = fb;
        this.dialog = dialog;
        this.changeIndicator = false;
        this.PanelControl = [
            { action: 'call', translate: 'Звонок' },
            { action: 'meet', translate: 'Встреча' },
            { action: 'task', translate: 'Задача' },
        ];
        this.LeadStatus = [
            { status: 'identifyLPR', translate: 'Выявление ЛПР' },
            { status: 'attemptCommunicateLPR', translate: 'Попытка связаться с ЛПР' },
            { status: 'identifyNeed', translate: 'Выявление потребности у ЛПР' },
            { status: 'offerSended', translate: 'Отправленно КП' },
            { status: 'DoesntReqFurtherWork', translate: 'Не требует дальнейшей работы' },
        ];
        this.Lead = {
            leadId: String,
            leadStatus: String,
            contactPhones: [],
            comments: [],
            tasks: []
        };
        this.taskPanelControl = [
            { action: 'comment', translate: 'Комментарий' },
            { action: 'call', translate: 'Звонок' },
            { action: 'meet', translate: 'Встреча' },
            { action: 'task', translate: 'Задача' },
        ];
        this.sub = this.route.params.subscribe(function (params) {
            _this.id = params['id']; // (+) converts string 'id' to a number
        });
    }
    LeadPageComponent.prototype.openDialog = function () {
        var dialogRef = this.dialog.open(_Offers_offer_into_lead_offer_into_lead_component__WEBPACK_IMPORTED_MODULE_6__["OfferIntoLeadComponent"], {
            position: {
                'top': '0',
                'right': '0'
            },
            maxWidth: 'none',
            minWidth: '80vh',
            height: '100vh',
            data: { leadId: this.Lead.leadId }
        });
        dialogRef.afterClosed().subscribe(function (result) {
            console.log('The dialog was closed');
        });
    };
    LeadPageComponent.prototype.ngOnInit = function () {
        this.getLeadInfo();
        this.taskDesk = this.fb.group({
            actions: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            description: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            deadLineDate: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]
        });
        this.taskDesk.valueChanges
            .subscribe(function (value) { return console.log(value); });
    };
    LeadPageComponent.prototype.getLeadInfo = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.myHttp.postHTTP('http://localhost:3000/getLeadInfo', { id: this.id })
                            .subscribe(function (data) {
                            console.log(data);
                            _this.Lead = data;
                            _this.sortTasks();
                            return;
                        }, function (err) {
                            console.log('Error to load Lead Page: ' + err);
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    LeadPageComponent.prototype.setUpdeteToLead = function () {
        return this.myHttp.putHTTP('/updateLead', this.Lead);
    };
    LeadPageComponent.prototype.sortTasks = function () {
        this.TaskDesk = this.Lead.tasks.concat(this.Lead.comments);
        this.TaskDesk.sort(function (a, b) {
            var aStatus = a.status !== 'started', bStatus = b.status !== 'started', aVal = a.finishedDate || a.createdDate, bVal = b.finishedDate || b.createdDate;
            return (aStatus - bStatus) || Date.parse(bVal) - Date.parse(aVal);
        });
    };
    LeadPageComponent.prototype.changeTaskStatus = function (task) {
        var _this = this;
        console.log(task);
        this.myHttp.postHTTP('http://localhost:3000/changeStatus', { leadId: this.Lead.leadId, changedTask: task })
            .subscribe(function (data) {
            console.log(data);
            _this.Lead = data;
            _this.sortTasks();
            return;
        }, function (err) {
            console.log('Error to load Lead Page: ' + err);
        });
    };
    LeadPageComponent.prototype.createNewTask = function () {
        var _this = this;
        var data;
        if (this.taskDesk.value.actions === 'comment') {
            data = {
                description: this.taskDesk.value.description,
                createdDate: new Date
            };
            this.myHttp.postHTTP('http://localhost:3000/createNewComment', { leadId: this.Lead.leadId, comment: data })
                .subscribe(function (updatedLead) {
                _this.Lead = updatedLead;
                _this.sortTasks();
                console.log(_this.Lead);
                return;
            }, function (err) {
                console.log('Error to add new Comment: ' + err);
            });
        }
        else {
            data = {
                status: 'started',
                action: this.taskDesk.value.actions,
                description: this.taskDesk.value.description,
                deadLineDate: this.taskDesk.value.deadLineDate,
                createdDate: new Date
            };
            this.myHttp.postHTTP('http://localhost:3000/createNewTask', { leadId: this.Lead.leadId, task: data })
                .subscribe(function (updatedLead) {
                _this.Lead = updatedLead;
                _this.sortTasks();
                console.log(_this.Lead);
                return;
            }, function (err) {
                console.log('Error to add new Comment: ' + err);
            });
        }
    };
    LeadPageComponent.prototype.changeLeadStatus = function () {
        var _this = this;
        this.myHttp.postHTTP('http://localhost:3000/changeLeadStatus', {
            leadId: this.Lead.leadId,
            leadStatus: this.Lead.leadStatus
        })
            .subscribe(function (data) {
            _this.alert.openSnackBar(data.message);
        }, function (err) {
            _this.alert.openSnackBar(err);
        });
    };
    LeadPageComponent.prototype.preChangeLead = function (e, boolean) {
        e.preventDefault();
        if (boolean === true) {
            return this.changeIndicator = true;
        }
        return this.changeIndicator = false;
    };
    LeadPageComponent.prototype.addNewPhone = function (e) {
        e.preventDefault();
        return this.Lead.contactPhones.push('');
    };
    LeadPageComponent.prototype.saveLeadChanges = function () {
        var _this = this;
        this.myHttp.postHTTP('http://localhost:3000/saveLeadChanges', {
            leadId: this.Lead.leadId,
            firmName: this.Lead.firmName,
            contactPhones: this.Lead.contactPhones,
            contactEmail: this.Lead.contactEmail,
            address: this.Lead.address,
            contactName: this.Lead.contactName,
            position: this.Lead.position,
            lprsName: this.Lead.lprsName
        })
            .subscribe(function (data) {
            _this.alert.openSnackBar(data.message);
            _this.changeIndicator = false;
        }, function (err) {
            _this.alert.openSnackBar(err);
        });
    };
    LeadPageComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-lead-page',
            template: __webpack_require__(/*! ./lead-page.component.html */ "./src/app/CRM/Leads/lead-page/lead-page.component.html"),
            styles: [__webpack_require__(/*! ./lead-page.component.styl */ "./src/app/CRM/Leads/lead-page/lead-page.component.styl")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_alert_alert_service__WEBPACK_IMPORTED_MODULE_7__["AlertService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            src_app_services_HTTP_myhttp_service__WEBPACK_IMPORTED_MODULE_3__["myHTTPService"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"],
            _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatDialog"]])
    ], LeadPageComponent);
    return LeadPageComponent;
}());



/***/ }),

/***/ "./src/app/CRM/Leads/new-lead/new-lead.component.html":
/*!************************************************************!*\
  !*** ./src/app/CRM/Leads/new-lead/new-lead.component.html ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<button mat-raised-button color=\"primary\" [matMenuTriggerFor]=\"menu\">Действия с Лидом</button>\r\n<mat-menu #menu=\"matMenu\">\r\n    <button mat-menu-item (click)='createNewLead()'>Создать Лид</button>\r\n    <button mat-menu-item (click)='createNewLeadOffer()'>Создать Лид + Предложение</button>\r\n    <button mat-menu-item (click)='createNewLeadOfferSend()'>Создать Лид + Предложение + отправить</button>\r\n</mat-menu>\r\n<button (click)='openSnackBar()'>reset</button>\r\n<section>\r\n    <form [formGroup]=\"LeadControl\">\r\n        <div class=\"wrapp\">\r\n            <mat-form-field>\r\n                <input matInput (change)=\"pars2gis()\" type=\"text\" formControlName=\"link2gis\" placeholder=\"Ссылка 2gis\">\r\n            </mat-form-field>\r\n    \r\n            <mat-form-field>\r\n                <mat-select placeholder=\"Статус Лида\" formControlName=\"leadStatus\">\r\n                    <mat-option *ngFor=\"let x of LeadStatus;\" [value]=\"x.status\">\r\n                    {{x.translate}}\r\n                    </mat-option>\r\n                </mat-select>\r\n            </mat-form-field>\r\n    \r\n            <mat-form-field>\r\n                <input matInput type=\"text\" formControlName=\"firmName\" placeholder=\"Название фирмы\">\r\n            </mat-form-field>                \r\n    \r\n            <div class=\"w-100\">\r\n                <div formArrayName=\"contactPhones\"\r\n                *ngFor=\"let phone of LeadControl.get('contactPhones').controls; let i = index;\">\r\n                    <mat-form-field>\r\n                        <input matInput type=\"text\" formControlName=\"{{i}}\" placeholder=\"Номер телефона\">\r\n                    </mat-form-field>\r\n                    <button mat-mini-fab color=\"warn\" (click)='removeContactPhoneControl(i)'>X</button>\r\n                </div>\r\n                <a href=\"#\" (click)='addContactPhoneControl($event)'>Добавить номер</a>\r\n            </div>\r\n    \r\n            <mat-form-field>\r\n                <input matInput type=\"text\" formControlName=\"address\" placeholder=\"Адрес\">\r\n            </mat-form-field>\r\n    \r\n            <mat-form-field>\r\n                <input matInput type=\"text\" formControlName=\"contactName\" placeholder=\"Имя собеседника\">\r\n            </mat-form-field>\r\n    \r\n            <mat-form-field>\r\n                <input matInput type=\"text\" formControlName=\"position\" placeholder=\"Его должность\">\r\n            </mat-form-field>\r\n    \r\n            <mat-form-field>\r\n                <input matInput type=\"email\" formControlName=\"contactEmail\" placeholder=\"E-mail\">\r\n            </mat-form-field>\r\n    \r\n            <mat-form-field>\r\n                <input matInput type=\"text\" formControlName=\"lprsName\" placeholder=\"ФИО ЛПР\">\r\n            </mat-form-field>\r\n    \r\n        </div>\r\n        <div class=\"wrapp\">\r\n    \r\n            <div class=\"w-100\" formArrayName=\"tasks\"\r\n            *ngFor=\"let phone of LeadControl.get('tasks').controls; let i = index;\">\r\n                <mat-form-field [formGroupName]=\"i\">\r\n                    <mat-select placeholder=\"Задача\" formControlName=\"action\">\r\n                        <mat-option *ngFor=\"let x of PanelControl;\" [value]=\"x.action\">\r\n                        {{x.translate}}\r\n                        </mat-option>\r\n                    </mat-select>\r\n                </mat-form-field>\r\n            </div>\r\n    \r\n            <div class=\"w-100\" formArrayName=\"tasks\"\r\n            *ngFor=\"let phone of LeadControl.get('tasks').controls; let i = index;\">\r\n                <mat-form-field [formGroupName]=\"i\" style=\"width: 100%;\">\r\n                    <textarea matInput formControlName=\"description\" placeholder=\"Описание задачи\"></textarea>\r\n                </mat-form-field>\r\n            </div>\r\n    \r\n            <div class=\"w-100\" formArrayName=\"tasks\"\r\n            *ngFor=\"let phone of LeadControl.get('tasks').controls; let i = index;\">\r\n                <mat-form-field [formGroupName]=\"i\">\r\n                    <input matInput formControlName=\"deadLineDate\" [owlDateTime]=\"dt1\" [owlDateTimeTrigger]=\"dt1\" placeholder=\"Дата задачи\">\r\n                    <owl-date-time #dt1 firstDayOfWeek='1' stepMinute='15'></owl-date-time>\r\n                </mat-form-field>\r\n            </div>\r\n    \r\n            <div class=\"w-100\" formArrayName=\"comments\"\r\n            *ngFor=\"let phone of LeadControl.get('comments').controls; let i = index;\">\r\n                <mat-form-field [formGroupName]=\"i\" style=\"width: 100%;\">\r\n                    <textarea matInput formControlName=\"description\" placeholder=\"Комментарий лида\"></textarea>\r\n                </mat-form-field>\r\n            </div>\r\n        </div>\r\n    </form>\r\n    \r\n    <form [formGroup]=\"OfferControl\">\r\n        <div class=\"wrapp\">\r\n                <mat-form-field>\r\n                    <mat-select (selectionChange)=\"calculate()\" placeholder=\"Регулярность\" formControlName=\"regular\">\r\n                        <mat-option *ngFor=\"let x of RegularControl;\" [value]=\"x.days\">\r\n                        {{x.translate}}\r\n                        </mat-option>\r\n                    </mat-select>\r\n                </mat-form-field>\r\n        \r\n                <mat-form-field>\r\n                    <input matInput (change)=\"calculate()\" type=\"number\" formControlName=\"area\" placeholder=\"Площадь\">\r\n                </mat-form-field>\r\n        \r\n                <mat-form-field>\r\n                    <input matInput (change)=\"calculate()\" type=\"number\" formControlName=\"time\" placeholder=\"Время на объекте\">\r\n                </mat-form-field>\r\n\r\n                <mat-checkbox (change)=\"calculate()\" formControlName=\"twice\">Убираться 2 раза</mat-checkbox>\r\n\r\n                <p *ngIf=\"Result.fot > 1\"> Фот: {{Result.fot}}</p>\r\n                <p *ngIf=\"Result.profit > 1\">Прибыль: {{Result.profit}}</p>\r\n                <p *ngIf=\"Result.itog > 1\">Итог: {{Result.itog}}</p>\r\n                <p *ngIf=\"Result.itogMaterial > 1\">Итог мат: {{Result.itogMaterial}}</p>\r\n        </div>   \r\n\r\n    </form>\r\n\r\n</section>"

/***/ }),

/***/ "./src/app/CRM/Leads/new-lead/new-lead.component.styl":
/*!************************************************************!*\
  !*** ./src/app/CRM/Leads/new-lead/new-lead.component.styl ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "section {\n  display: flex;\n  flex-direction: row;\n  width: 980px;\n  margin: 0 auto;\n}\nsection form {\n  display: flex;\n  flex-direction: row;\n  justify-content: center;\n}\nsection form:nth-of-type(1) {\n  flex: 7;\n}\nsection form:nth-of-type(1) div:nth-of-type(1) {\n  flex: 3;\n}\nsection form:nth-of-type(1) div:nth-of-type(2) {\n  flex: 5;\n}\nsection form:nth-of-type(2) {\n  flex: 2;\n}\nsection form div.wrapp {\n  padding: 0 16px;\n}\n/*# sourceMappingURL=src/app/CRM/Leads/new-lead/new-lead.component.css.map */\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvQ1JNL0xlYWRzL25ldy1sZWFkL3NyYy9hcHAvQ1JNL0xlYWRzL25ldy1sZWFkL25ldy1sZWFkLmNvbXBvbmVudC5zdHlsIiwic3JjL2FwcC9DUk0vTGVhZHMvbmV3LWxlYWQvbmV3LWxlYWQuY29tcG9uZW50LnN0eWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxhQUFRO0VBQ1IsbUJBQWU7RUFDZixZQUFNO0VBQ04sY0FBTztBQ0NYO0FEQUk7RUFDSSxhQUFRO0VBQ1IsbUJBQWU7RUFDZix1QkFBZ0I7QUNFeEI7QUREUTtFQUNJLE9BQUs7QUNHakI7QUREZ0I7RUFDSSxPQUFLO0FDR3pCO0FERmdCO0VBQ0ksT0FBSztBQ0l6QjtBREhRO0VBQ0ksT0FBSztBQ0tqQjtBREpRO0VBQ0ksZUFBUztBQ01yQjtBQUNBLDRFQUE0RSIsImZpbGUiOiJzcmMvYXBwL0NSTS9MZWFkcy9uZXctbGVhZC9uZXctbGVhZC5jb21wb25lbnQuc3R5bCIsInNvdXJjZXNDb250ZW50IjpbInNlY3Rpb24gXHJcbiAgICBkaXNwbGF5IGZsZXhcclxuICAgIGZsZXgtZGlyZWN0aW9uIHJvd1xyXG4gICAgd2lkdGggOTgwcHggXHJcbiAgICBtYXJnaW4gMCBhdXRvXHJcbiAgICBmb3JtXHJcbiAgICAgICAgZGlzcGxheSBmbGV4XHJcbiAgICAgICAgZmxleC1kaXJlY3Rpb24gcm93XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50IGNlbnRlclxyXG4gICAgICAgICY6bnRoLW9mLXR5cGUoMSlcclxuICAgICAgICAgICAgZmxleCA3XHJcbiAgICAgICAgICAgICYgZGl2XHJcbiAgICAgICAgICAgICAgICAmOm50aC1vZi10eXBlKDEpXHJcbiAgICAgICAgICAgICAgICAgICAgZmxleCAzXHJcbiAgICAgICAgICAgICAgICAmOm50aC1vZi10eXBlKDIpXHJcbiAgICAgICAgICAgICAgICAgICAgZmxleCA1XHJcbiAgICAgICAgJjpudGgtb2YtdHlwZSgyKVxyXG4gICAgICAgICAgICBmbGV4IDJcclxuICAgICAgICBkaXYud3JhcHBcclxuICAgICAgICAgICAgcGFkZGluZyAgMCAxNnB4XHJcbiIsInNlY3Rpb24ge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICB3aWR0aDogOTgwcHg7XG4gIG1hcmdpbjogMCBhdXRvO1xufVxuc2VjdGlvbiBmb3JtIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5zZWN0aW9uIGZvcm06bnRoLW9mLXR5cGUoMSkge1xuICBmbGV4OiA3O1xufVxuc2VjdGlvbiBmb3JtOm50aC1vZi10eXBlKDEpIGRpdjpudGgtb2YtdHlwZSgxKSB7XG4gIGZsZXg6IDM7XG59XG5zZWN0aW9uIGZvcm06bnRoLW9mLXR5cGUoMSkgZGl2Om50aC1vZi10eXBlKDIpIHtcbiAgZmxleDogNTtcbn1cbnNlY3Rpb24gZm9ybTpudGgtb2YtdHlwZSgyKSB7XG4gIGZsZXg6IDI7XG59XG5zZWN0aW9uIGZvcm0gZGl2LndyYXBwIHtcbiAgcGFkZGluZzogMCAxNnB4O1xufVxuLyojIHNvdXJjZU1hcHBpbmdVUkw9c3JjL2FwcC9DUk0vTGVhZHMvbmV3LWxlYWQvbmV3LWxlYWQuY29tcG9uZW50LmNzcy5tYXAgKi8iXX0= */"

/***/ }),

/***/ "./src/app/CRM/Leads/new-lead/new-lead.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/CRM/Leads/new-lead/new-lead.component.ts ***!
  \**********************************************************/
/*! exports provided: NewLeadComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewLeadComponent", function() { return NewLeadComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_calculate_calculate_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/calculate/calculate.service */ "./src/app/services/calculate/calculate.service.ts");
/* harmony import */ var src_app_services_HTTP_myhttp_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/HTTP/myhttp.service */ "./src/app/services/HTTP/myhttp.service.ts");
/* harmony import */ var guid_typescript__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! guid-typescript */ "./node_modules/guid-typescript/dist/guid.js");
/* harmony import */ var guid_typescript__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(guid_typescript__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var src_app_services_alert_alert_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/alert/alert.service */ "./src/app/services/alert/alert.service.ts");







var NewLeadComponent = /** @class */ (function () {
    function NewLeadComponent(alert, fb, svc, myHttp) {
        this.alert = alert;
        this.fb = fb;
        this.svc = svc;
        this.myHttp = myHttp;
        this.Result = {
            fot: Number,
            itog: Number,
            itogMaterial: Number,
            managerWage: Number,
            material: Number,
            profit: Number,
            tinkoffCommission: Number,
            windowFond: Number,
        };
        this.RegularControl = [
            { days: '30', translate: 'Без выходных' },
            { days: '25.8', translate: '6/1 - сб полный' },
            { days: '23.7', translate: '6/1 - сб не полный' },
            { days: '21.5', translate: '5/2' },
            { days: '15', translate: '2/2' },
            { days: '13', translate: '3 раза в неделю' },
            { days: '8.6', translate: '2 раза в неделю' },
            { days: '4.3', translate: 'Раз в неделю' },
            { days: '1', translate: 'Раз в месяц' }
        ];
        this.PanelControl = [
            { action: 'call', translate: 'Звонок' },
            { action: 'meet', translate: 'Встреча' },
            { action: 'task', translate: 'Задача' },
        ];
        this.LeadStatus = [
            { status: 'identifyLPR', translate: 'Выявление ЛПР' },
            { status: 'attemptCommunicateLPR', translate: 'Попытка связаться с ЛПР' },
            { status: 'identifyNeed', translate: 'Выявление потребности у ЛПР' },
            { status: 'offerSended', translate: 'Отправленно КП' },
            { status: 'DoesntReqFurtherWork', translate: 'Не требует дальнейшей работы' },
        ];
    }
    NewLeadComponent.prototype.ngOnInit = function () {
        this.LeadControl = this.fb.group({
            leadId: guid_typescript__WEBPACK_IMPORTED_MODULE_4__["Guid"].create().toString(),
            leadStatus: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
            firmName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
            contactPhones: this.fb.array([['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]]),
            contactName: '',
            position: '',
            contactEmail: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].email],
            address: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
            lprsName: '',
            comments: this.fb.array([
                this.fb.group({
                    description: '',
                    createdDate: new Date
                })
            ]),
            tasks: this.fb.array([
                this.fb.group({
                    status: 'started',
                    action: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
                    description: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
                    createdDate: new Date,
                    deadLineDate: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]
                })
            ]),
            link2gis: '',
            createdDate: new Date
        });
        this.OfferControl = this.fb.group({
            leadLink: this.LeadControl.get('leadId').value,
            area: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
            regular: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
            time: '',
            twice: false,
            status: '',
            createdDate: new Date,
            sentingDate: '',
            details: this.fb.group({
                fot: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
                managerWage: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
                tinkoffCommission: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
                windowFond: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
                material: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
                profit: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
                itog: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
                itogMaterial: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
            })
        });
        this.LeadControl.valueChanges
            .subscribe(function (value) { return console.log(value); });
        this.OfferControl.valueChanges
            .subscribe(function (value) { return console.log(value); });
    }; //ngOnInit finished
    //methods to control contactPhone inputs
    NewLeadComponent.prototype.removeContactPhoneControl = function (index) {
        if (this.LeadControl.controls['contactPhones'].length > 1) {
            this.LeadControl.controls['contactPhones'].removeAt(index);
        }
    };
    NewLeadComponent.prototype.addContactPhoneControl = function (e) {
        e.preventDefault();
        this.LeadControl.get('contactPhones').push(new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"]);
    };
    //methods to control contactPhone inputs
    NewLeadComponent.prototype.calculate = function () {
        if (this.OfferControl.get('area').value > 0 && this.OfferControl.get('regular').value > 0) {
            this.OfferControl.get('details').setValue(this.svc.getCalculate(this.OfferControl.get('area').value, this.OfferControl.get('regular').value, this.OfferControl.get('time').value, this.OfferControl.get('twice').value));
            this.Result = this.OfferControl.get('details').value;
            return this.Result;
        }
    };
    NewLeadComponent.prototype.pars2gis = function () {
        var _this = this;
        return this.myHttp.postHTTP('http://localhost:3000/pars2gis', { link: this.LeadControl.get('link2gis').value })
            .subscribe(function (data) {
            for (var x in _this.LeadControl.value) {
                for (var y in data) {
                    if (x === y) {
                        if (x == 'contactPhones') {
                            console.log(data[y].length);
                            _this.LeadControl.get(x).removeAt(0);
                            for (var i = 0; i < data[y].length; i++) {
                                _this.LeadControl.get(x).push(new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](data[y][i]));
                            }
                        }
                        else {
                            _this.LeadControl.get(x).setValue(data[y]);
                        }
                    }
                }
            }
            console.log(data);
        }, function (err) {
            console.log(err);
        });
    }; //pars2gis
    NewLeadComponent.prototype.resetForm = function () {
        this.LeadControl.reset();
        this.OfferControl.reset();
    };
    NewLeadComponent.prototype.createNewLead = function () {
        var _this = this;
        this.valid(this.LeadControl);
        if (this.LeadControl.valid) {
            var data = this.clearLead(this.LeadControl);
            return this.myHttp.postHTTP('http://localhost:3000/newLead', data)
                .subscribe(function (data) {
                _this.alert.openSnackBar(data.message);
            }, function (err) {
                _this.alert.openSnackBar(err);
            });
            //Добавить отчистку объекта
        }
        else {
            this.alert.openSnackBar('🤦‍ Заполнены не все поля!');
        }
    }; //createNewLead
    NewLeadComponent.prototype.createNewLeadOffer = function () {
        var _this = this;
        this.valid(this.LeadControl);
        this.valid(this.OfferControl);
        if (this.LeadControl.valid && this.OfferControl.valid) {
            var data = this.clearLead(this.LeadControl);
            this.OfferControl.get('status').setValue('created');
            return this.myHttp.postHTTP('http://localhost:3000/newLeadOffer', { Lead: data, Offer: this.OfferControl.value })
                .subscribe(function (data) {
                _this.alert.openSnackBar(data.message);
            }, function (err) {
                _this.alert.openSnackBar(err);
            });
        }
        else {
            this.alert.openSnackBar('🤦‍ Заполнены не все поля!');
        }
    };
    NewLeadComponent.prototype.createNewLeadOfferSend = function () {
        var _this = this;
        this.LeadControl.get('contactEmail').setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]);
        this.LeadControl.get('contactEmail').updateValueAndValidity();
        this.valid(this.LeadControl);
        this.valid(this.OfferControl);
        if (this.LeadControl.valid && this.OfferControl.valid) {
            var data = this.clearLead(this.LeadControl);
            this.OfferControl.get('status').setValue('sent');
            this.OfferControl.get('sentingDate').setValue(new Date);
            return this.myHttp.postHTTP('http://localhost:3000/newLeadOfferSend', { Lead: data, Offer: this.OfferControl.value })
                .subscribe(function (data) {
                _this.alert.openSnackBar(data.message);
            }, function (err) {
                _this.alert.openSnackBar(err);
            });
        }
        else {
            this.alert.openSnackBar('🤦‍ Заполнены не все поля!');
        }
    };
    NewLeadComponent.prototype.clearLead = function (group) {
        var copeLead = group.value;
        Object.keys(copeLead).forEach(function (key) {
            if (typeof (copeLead[key]) === 'string' &&
                (copeLead[key] === null || copeLead[key] === '')) {
                delete copeLead[key];
            }
            else if (Array.isArray(copeLead[key])) {
                for (var _i = 0, _a = copeLead[key]; _i < _a.length; _i++) {
                    var x = _a[_i];
                    if (x instanceof Object) {
                        for (var y in x) {
                            if (x[y] === null || x[y] === '') {
                                copeLead[key] = [];
                            }
                        }
                    }
                }
            }
        });
        return copeLead;
    };
    NewLeadComponent.prototype.valid = function (group) {
        var copeLead = group.controls;
        Object.keys(copeLead).forEach(function (key) {
            if (copeLead[key] instanceof _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"]) {
                copeLead[key].markAsTouched();
            }
            else {
                for (var _i = 0, _a = copeLead[key].controls; _i < _a.length; _i++) {
                    var x = _a[_i];
                    x.markAsTouched();
                    for (var y in x.controls) {
                        x.controls[y].markAsTouched();
                    }
                }
            }
        });
    };
    ;
    NewLeadComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-new-lead',
            template: __webpack_require__(/*! ./new-lead.component.html */ "./src/app/CRM/Leads/new-lead/new-lead.component.html"),
            styles: [__webpack_require__(/*! ./new-lead.component.styl */ "./src/app/CRM/Leads/new-lead/new-lead.component.styl")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_alert_alert_service__WEBPACK_IMPORTED_MODULE_6__["AlertService"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"],
            src_app_services_calculate_calculate_service__WEBPACK_IMPORTED_MODULE_2__["CalculateService"],
            src_app_services_HTTP_myhttp_service__WEBPACK_IMPORTED_MODULE_3__["myHTTPService"]])
    ], NewLeadComponent);
    return NewLeadComponent;
}());



/***/ }),

/***/ "./src/app/CRM/Offers/offer-into-lead/offer-into-lead.component.html":
/*!***************************************************************************!*\
  !*** ./src/app/CRM/Offers/offer-into-lead/offer-into-lead.component.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n    <div class=\"row\">\n      <div class=\"col-6\">\n        <form [formGroup]=\"OfferControl\">\n          <mat-form-field>\n              <mat-select (selectionChange)=\"newCalculate()\" placeholder=\"Регулярность\" formControlName=\"regular\">\n                  <mat-option *ngFor=\"let x of RegularControl;\" [value]=\"x.days\">\n                  {{x.translate}}\n                  </mat-option>\n              </mat-select>\n          </mat-form-field><br>\n  \n          <mat-form-field>\n              <input matInput (change)=\"newCalculate()\" type=\"number\" formControlName=\"area\" placeholder=\"Площадь\">\n          </mat-form-field><br>\n  \n          <mat-form-field>\n              <input matInput (change)=\"newCalculate()\" type=\"number\" formControlName=\"time\" placeholder=\"Время на объекте\">\n          </mat-form-field><br>\n          <mat-checkbox (change)=\"newCalculate()\" formControlName=\"twice\">Убираться 2 раза</mat-checkbox><br>\n          <button mat-raised-button color=\"primary\" (click)='createNewOffer()'>Сохранить</button>\n        \n  \n      </form>\n      </div>\n      <div class=\"col-6\">\n        <p *ngIf=\"Result.fot > 1\"> Фот: {{Result.fot}}</p>\n        <p *ngIf=\"Result.profit > 1\">Прибыль: {{Result.profit}}</p>\n        <p *ngIf=\"Result.itog > 1\">Итог: {{Result.itog}}</p>\n        <p *ngIf=\"Result.itogMaterial > 1\">Итог мат: {{Result.itogMaterial}}</p>\n      </div>\n    </div>\n  <div class=\"row\">\n\n    <div class=\"col-4\">\n      <div class=\"wrapp\" *ngFor=\"let x of Offers; index as i\">\n        <p *ngIf='x.area && changeIndicator != i'>Площадь: {{x.area}} м<sup>2</sup></p>\n        <mat-form-field *ngIf='changeIndicator === i'>\n            <input matInput placeholder=\"Площадь\" (change)=\"calculate(i)\" [(ngModel)]='x.area'>\n        </mat-form-field>\n        <p *ngIf='changeIndicator != i'>Регулярность: {{x.regular}}</p>\n\n        <mat-form-field *ngIf='changeIndicator === i'>\n            <mat-select (selectionChange)=\"calculate(i)\" placeholder=\"Регулярность\" [(ngModel)]='x.regular'>\n                <mat-option *ngFor=\"let y of RegularControl;\" [value]=\"y.days\">\n                {{y.translate}}\n                </mat-option>\n            </mat-select>\n        </mat-form-field>\n\n        <p *ngIf='x.time && changeIndicator != i'>Время на объекте: {{x.time}}</p>\n        <mat-form-field *ngIf='changeIndicator === i'>\n            <input matInput placeholder=\"Время на объекте\" (change)=\"calculate(i)\" [(ngModel)]='x.time'>\n        </mat-form-field>\n        <p *ngIf='x.twice === true && changeIndicator != i'>Уборка 2 раза в день</p>\n        <mat-checkbox *ngIf='changeIndicator === i' (change)=\"calculate(i)\" [(ngModel)]='x.twice'>Уборка 2 раза в день</mat-checkbox>\n        <br>\n        <button mat-raised-button color=\"primary\" *ngIf='changeIndicator === i' (click)='saveOfferChanges(i)'>Сохранить</button>\n        <p>Статус: {{x.status}}</p>\n        \n        <p *ngIf='x.sentingDate'>Дата отправки: {{x.sentingDate}}</p>\n        <p class=\"font-weight-bold\">Итог: {{x.details.itog}} ₽</p>\n        <p class=\"font-weight-bold\">Итог с материалами: {{x.details.itogMaterial}} ₽</p>\n        <span class='created-date'>Дата создания: {{x.createdDate | date: 'dd.MM.yyyy HH:mm'}}</span>\n        <mat-icon [matMenuTriggerFor]=\"menu\" class='offer-menu'>more_vert</mat-icon>\n        <mat-menu #menu=\"matMenu\">\n          <button mat-menu-item (click)='preChangeOffer(i)'>Изменить</button>\n          <button mat-menu-item (click)=\"openBottomSheet(i)\">Просмотр деталей</button>\n          <button mat-menu-item (click)=\"sentOffer(i)\">Отправить</button>\n          <button mat-menu-item (click)=\"deleteOffer(i)\">Удалить</button>\n        </mat-menu>\n      </div>\n    </div>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/CRM/Offers/offer-into-lead/offer-into-lead.component.styl":
/*!***************************************************************************!*\
  !*** ./src/app/CRM/Offers/offer-into-lead/offer-into-lead.component.styl ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".cdk-overlay-pane {\n  background-color: #eef2f4;\n}\n.wrapp {\n  position: relative;\n  background-color: #fff;\n  margin-bottom: 1rem;\n  box-shadow: 0 1px 1px 0 rgba(0,0,0,0.04);\n  padding: 20px;\n  border-radius: 10px;\n  border: 1px solid rgba(0,0,0,0.2);\n}\n.wrapp .change-lead {\n  position: absolute;\n  right: 10px;\n  top: 10px;\n}\n.wrapp .created-date {\n  position: absolute;\n  font-size: 0.7rem;\n  right: 20px;\n}\n.wrapp .deadline-date {\n  font-size: 0.8rem !important;\n  padding-left: 10px;\n}\n.wrapp .offer-menu {\n  position: absolute;\n  top: 10px;\n  right: 10px;\n}\n.wrapp .offer-menu:hover {\n  cursor: pointer;\n}\n.wrapp p {\n  margin-bottom: 0;\n}\n/*# sourceMappingURL=src/app/CRM/Offers/offer-into-lead/offer-into-lead.component.css.map */\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvQ1JNL09mZmVycy9vZmZlci1pbnRvLWxlYWQvc3JjL2FwcC9DUk0vT2ZmZXJzL29mZmVyLWludG8tbGVhZC9vZmZlci1pbnRvLWxlYWQuY29tcG9uZW50LnN0eWwiLCJzcmMvYXBwL0NSTS9PZmZlcnMvb2ZmZXItaW50by1sZWFkL29mZmVyLWludG8tbGVhZC5jb21wb25lbnQuc3R5bCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHlCQUFrQjtBQ0N0QjtBREFBO0VBQ0ksa0JBQVM7RUFDVCxzQkFBaUI7RUFDakIsbUJBQWM7RUFDZCx3Q0FBWTtFQUNaLGFBQVE7RUFDUixtQkFBZTtFQUNmLGlDQUFPO0FDRVg7QURESTtFQUNJLGtCQUFTO0VBQ1QsV0FBTTtFQUNOLFNBQUk7QUNHWjtBREZJO0VBQ0ksa0JBQVM7RUFDVCxpQkFBVztFQUNYLFdBQU07QUNJZDtBREhJO0VBQ0ksNEJBQVc7RUFDWCxrQkFBYTtBQ0tyQjtBREpJO0VBQ0ksa0JBQVM7RUFDVCxTQUFJO0VBQ0osV0FBTTtBQ01kO0FETFE7RUFDSSxlQUFPO0FDT25CO0FETkk7RUFDSSxnQkFBYztBQ1F0QjtBQUNBLDJGQUEyRiIsImZpbGUiOiJzcmMvYXBwL0NSTS9PZmZlcnMvb2ZmZXItaW50by1sZWFkL29mZmVyLWludG8tbGVhZC5jb21wb25lbnQuc3R5bCIsInNvdXJjZXNDb250ZW50IjpbIi5jZGstb3ZlcmxheS1wYW5lXHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWVmMmY0O1xyXG4ud3JhcHBcclxuICAgIHBvc2l0aW9uIHJlbGF0aXZlXHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yIHdoaXRlXHJcbiAgICBtYXJnaW4tYm90dG9tIDFyZW1cclxuICAgIGJveC1zaGFkb3c6IDAgMXB4IDFweCAwIHJnYmEoMCwwLDAsLjA0KTtcclxuICAgIHBhZGRpbmcgMjBweFxyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweFxyXG4gICAgYm9yZGVyIDFweCBzb2xpZCByZ2JhKDAsMCwwLC4yKTtcclxuICAgICYgLmNoYW5nZS1sZWFkXHJcbiAgICAgICAgcG9zaXRpb24gYWJzb2x1dGVcclxuICAgICAgICByaWdodCAxMHB4XHJcbiAgICAgICAgdG9wIDEwcHhcclxuICAgICYgLmNyZWF0ZWQtZGF0ZSBcclxuICAgICAgICBwb3NpdGlvbiBhYnNvbHV0ZVxyXG4gICAgICAgIGZvbnQtc2l6ZTogLjdyZW1cclxuICAgICAgICByaWdodCAyMHB4XHJcbiAgICAmIC5kZWFkbGluZS1kYXRlXHJcbiAgICAgICAgZm9udC1zaXplOiAuOHJlbSFpbXBvcnRhbnRcclxuICAgICAgICBwYWRkaW5nLWxlZnQgMTBweFxyXG4gICAgJiAub2ZmZXItbWVudVxyXG4gICAgICAgIHBvc2l0aW9uIGFic29sdXRlXHJcbiAgICAgICAgdG9wIDEwcHhcclxuICAgICAgICByaWdodCAxMHB4XHJcbiAgICAgICAgJjpob3ZlclxyXG4gICAgICAgICAgICBjdXJzb3IgcG9pbnRlclxyXG4gICAgJiBwXHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbSAwIiwiLmNkay1vdmVybGF5LXBhbmUge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWVmMmY0O1xufVxuLndyYXBwIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICBtYXJnaW4tYm90dG9tOiAxcmVtO1xuICBib3gtc2hhZG93OiAwIDFweCAxcHggMCByZ2JhKDAsMCwwLDAuMDQpO1xuICBwYWRkaW5nOiAyMHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDAsMCwwLDAuMik7XG59XG4ud3JhcHAgLmNoYW5nZS1sZWFkIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogMTBweDtcbiAgdG9wOiAxMHB4O1xufVxuLndyYXBwIC5jcmVhdGVkLWRhdGUge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGZvbnQtc2l6ZTogMC43cmVtO1xuICByaWdodDogMjBweDtcbn1cbi53cmFwcCAuZGVhZGxpbmUtZGF0ZSB7XG4gIGZvbnQtc2l6ZTogMC44cmVtICFpbXBvcnRhbnQ7XG4gIHBhZGRpbmctbGVmdDogMTBweDtcbn1cbi53cmFwcCAub2ZmZXItbWVudSB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAxMHB4O1xuICByaWdodDogMTBweDtcbn1cbi53cmFwcCAub2ZmZXItbWVudTpob3ZlciB7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cbi53cmFwcCBwIHtcbiAgbWFyZ2luLWJvdHRvbTogMDtcbn1cbi8qIyBzb3VyY2VNYXBwaW5nVVJMPXNyYy9hcHAvQ1JNL09mZmVycy9vZmZlci1pbnRvLWxlYWQvb2ZmZXItaW50by1sZWFkLmNvbXBvbmVudC5jc3MubWFwICovIl19 */"

/***/ }),

/***/ "./src/app/CRM/Offers/offer-into-lead/offer-into-lead.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/CRM/Offers/offer-into-lead/offer-into-lead.component.ts ***!
  \*************************************************************************/
/*! exports provided: OfferIntoLeadComponent, BottomSheet */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OfferIntoLeadComponent", function() { return OfferIntoLeadComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BottomSheet", function() { return BottomSheet; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var src_app_services_calculate_calculate_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/calculate/calculate.service */ "./src/app/services/calculate/calculate.service.ts");
/* harmony import */ var src_app_services_HTTP_myhttp_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/HTTP/myhttp.service */ "./src/app/services/HTTP/myhttp.service.ts");
/* harmony import */ var src_app_services_alert_alert_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/alert/alert.service */ "./src/app/services/alert/alert.service.ts");







var OfferIntoLeadComponent = /** @class */ (function () {
    function OfferIntoLeadComponent(bottomSheet, data, svc, myHttp, alert, fb) {
        this.bottomSheet = bottomSheet;
        this.data = data;
        this.svc = svc;
        this.myHttp = myHttp;
        this.alert = alert;
        this.fb = fb;
        this.changeIndicator = -1;
        this.Offers = [
            { details: Object }
        ];
        this.Result = {
            fot: Number,
            itog: Number,
            itogMaterial: Number,
            managerWage: Number,
            material: Number,
            profit: Number,
            tinkoffCommission: Number,
            windowFond: Number,
        };
        this.RegularControl = [
            { days: 30, translate: 'Без выходных' },
            { days: 25.8, translate: '6/1 - сб полный' },
            { days: 23.7, translate: '6/1 - сб не полный' },
            { days: 21.5, translate: '5/2' },
            { days: 15, translate: '2/2' },
            { days: 13, translate: '3 раза в неделю' },
            { days: 8.6, translate: '2 раза в неделю' },
            { days: 4.3, translate: 'Раз в неделю' },
            { days: 1, translate: 'Раз в месяц' }
        ];
    }
    OfferIntoLeadComponent.prototype.ngOnInit = function () {
        this.getLeadOffers();
        this.OfferControl = this.fb.group({
            leadLink: this.data.leadId,
            area: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            regular: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            time: '',
            twice: false,
            status: '',
            createdDate: new Date,
            sentingDate: '',
            details: this.fb.group({
                fot: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                managerWage: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                tinkoffCommission: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                windowFond: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                material: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                profit: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                itog: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                itogMaterial: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            })
        });
    };
    OfferIntoLeadComponent.prototype.newCalculate = function () {
        if (this.OfferControl.get('area').value > 0 && this.OfferControl.get('regular').value > 0) {
            this.OfferControl.get('details').setValue(this.svc.getCalculate(this.OfferControl.get('area').value, this.OfferControl.get('regular').value, this.OfferControl.get('time').value, this.OfferControl.get('twice').value));
            this.Result = this.OfferControl.get('details').value;
            return this.getLeadOffers();
        }
    };
    OfferIntoLeadComponent.prototype.createNewOffer = function () {
        var _this = this;
        this.valid(this.OfferControl);
        if (this.OfferControl.valid) {
            this.OfferControl.get('status').setValue('created');
            console.log(this.OfferControl.value);
            return this.myHttp.postHTTP('http://localhost:3000/newOffer', this.OfferControl.value)
                .subscribe(function (data) {
                _this.alert.openSnackBar(data.message);
                _this.getLeadOffers();
            }, function (err) {
                _this.alert.openSnackBar(err);
            });
        }
        else {
            this.alert.openSnackBar('🤦‍ Заполнены не все поля!');
        }
    };
    OfferIntoLeadComponent.prototype.deleteOffer = function (index) {
        var _this = this;
        console.log(this.Offers[index]);
        return this.myHttp.postHTTP('http://localhost:3000/deleteOffer', this.Offers[index])
            .subscribe(function (data) {
            _this.alert.openSnackBar(data.message);
            _this.getLeadOffers();
        }, function (err) {
            _this.alert.openSnackBar(err);
        });
    };
    ;
    OfferIntoLeadComponent.prototype.valid = function (group) {
        var copeLead = group.controls;
        Object.keys(copeLead).forEach(function (key) {
            if (copeLead[key] instanceof _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]) {
                copeLead[key].markAsTouched();
            }
            else {
                for (var _i = 0, _a = copeLead[key].controls; _i < _a.length; _i++) {
                    var x = _a[_i];
                    x.markAsTouched();
                    for (var y in x.controls) {
                        x.controls[y].markAsTouched();
                    }
                }
            }
        });
    };
    ;
    OfferIntoLeadComponent.prototype.getLeadOffers = function () {
        var _this = this;
        this.myHttp.postHTTP('http://localhost:3000/getAllOffersFromLead', { leadLink: this.data.leadId })
            .subscribe(function (data) {
            _this.Offers = data;
            console.log(data);
        }, function (err) {
            console.log(err);
        });
    };
    OfferIntoLeadComponent.prototype.preChangeOffer = function (index) {
        if (index > -1) {
            return this.changeIndicator = index;
        }
        return this.changeIndicator = index;
    };
    OfferIntoLeadComponent.prototype.calculate = function (index) {
        var offer = this.Offers[index];
        this.Offers[index].details = this.svc.getCalculate(offer.area, offer.regular, offer.time, offer.twice);
    };
    OfferIntoLeadComponent.prototype.saveOfferChanges = function (index) {
        var _this = this;
        this.changeIndicator = -1;
        this.myHttp.postHTTP('http://localhost:3000/saveOfferChanges', this.Offers[index])
            .subscribe(function (data) {
            _this.alert.openSnackBar(data.message);
        }, function (err) {
            _this.alert.openSnackBar(err);
        });
    };
    OfferIntoLeadComponent.prototype.openBottomSheet = function (i) {
        this.bottomSheet.open(BottomSheet, {
            data: { offer: this.Offers[i] }
        });
    };
    OfferIntoLeadComponent.prototype.sentOffer = function (index) {
        var _this = this;
        this.Offers[index].status = 'sent';
        this.myHttp.postHTTP('http://localhost:3000/sentOffer', this.Offers[index])
            .subscribe(function (data) {
            _this.alert.openSnackBar(data.message);
            _this.getLeadOffers();
        }, function (err) {
            _this.alert.openSnackBar(err);
        });
    };
    OfferIntoLeadComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-offer-into-lead',
            template: __webpack_require__(/*! ./offer-into-lead.component.html */ "./src/app/CRM/Offers/offer-into-lead/offer-into-lead.component.html"),
            styles: [__webpack_require__(/*! ./offer-into-lead.component.styl */ "./src/app/CRM/Offers/offer-into-lead/offer-into-lead.component.styl")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_material__WEBPACK_IMPORTED_MODULE_3__["MAT_DIALOG_DATA"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_material__WEBPACK_IMPORTED_MODULE_3__["MatBottomSheet"], Object, src_app_services_calculate_calculate_service__WEBPACK_IMPORTED_MODULE_4__["CalculateService"],
            src_app_services_HTTP_myhttp_service__WEBPACK_IMPORTED_MODULE_5__["myHTTPService"],
            src_app_services_alert_alert_service__WEBPACK_IMPORTED_MODULE_6__["AlertService"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]])
    ], OfferIntoLeadComponent);
    return OfferIntoLeadComponent;
}());

var BottomSheet = /** @class */ (function () {
    function BottomSheet(bottomSheetRef, data, myHttp, alert, svc) {
        this.bottomSheetRef = bottomSheetRef;
        this.data = data;
        this.myHttp = myHttp;
        this.alert = alert;
        this.svc = svc;
        this.changeIndicator = false;
        this.Offer = this.data.offer;
    }
    BottomSheet.prototype.openLink = function (event) {
        this.bottomSheetRef.dismiss();
        event.preventDefault();
    };
    BottomSheet.prototype.preChangeLead = function (e, boolean) {
        e.preventDefault();
        if (boolean === true) {
            return this.changeIndicator = true;
        }
        return this.changeIndicator = false;
    };
    BottomSheet.prototype.calculate = function () {
        var result = this.svc.getChangesCalculate(this.Offer);
        this.Offer.details.itog = result.itog;
        this.Offer.details.itogMaterial = result.itogMaterial;
        this.Offer.details.tinkoffCommission = result.tinkoffCommission;
    };
    BottomSheet.prototype.saveOfferDetailChanges = function () {
        var _this = this;
        this.changeIndicator = false;
        this.myHttp.postHTTP('http://localhost:3000/saveOfferDetailChanges', { data: this.Offer })
            .subscribe(function (data) {
            _this.alert.openSnackBar(data.message);
        }, function (err) {
            _this.alert.openSnackBar(err);
        });
    };
    BottomSheet = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'bottom-sheet-overview-example-sheet',
            template: __webpack_require__(/*! ./some.html */ "./src/app/CRM/Offers/offer-into-lead/some.html"),
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_material__WEBPACK_IMPORTED_MODULE_3__["MAT_BOTTOM_SHEET_DATA"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_material__WEBPACK_IMPORTED_MODULE_3__["MatBottomSheetRef"], Object, src_app_services_HTTP_myhttp_service__WEBPACK_IMPORTED_MODULE_5__["myHTTPService"],
            src_app_services_alert_alert_service__WEBPACK_IMPORTED_MODULE_6__["AlertService"],
            src_app_services_calculate_calculate_service__WEBPACK_IMPORTED_MODULE_4__["CalculateService"]])
    ], BottomSheet);
    return BottomSheet;
}());



/***/ }),

/***/ "./src/app/CRM/Offers/offer-into-lead/some.html":
/*!******************************************************!*\
  !*** ./src/app/CRM/Offers/offer-into-lead/some.html ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\" style='max-width: 500px; position: relative; padding: 10px;'>\r\n    <a href=\"#\" (click)='preChangeLead($event, true)' style=\"position: absolute; top: 10px; right: 10px;\">Изменить</a>\r\n    <div class=\"col-6\">\r\n        <p *ngIf='!changeIndicator'>ФОТ: {{Offer.details.fot}} м<sup>2</sup></p>\r\n        <mat-form-field *ngIf='changeIndicator'>\r\n            <input matInput placeholder=\"ФОТ\" (change)=\"calculate()\" [(ngModel)]='Offer.details.fot'>\r\n        </mat-form-field>\r\n    </div>\r\n    <div class=\"col-6\">\r\n        <p *ngIf='!changeIndicator'>УПР: {{Offer.details.managerWage}} ₽</p>\r\n        <mat-form-field *ngIf='changeIndicator'>\r\n            <input matInput placeholder=\"УПР\" (change)=\"calculate()\" [(ngModel)]='Offer.details.managerWage'>\r\n        </mat-form-field>\r\n    </div>\r\n    <div class=\"col-6\">\r\n        <p>Тинькофф: {{Offer.details.tinkoffCommission}} ₽</p>\r\n    </div>\r\n    <div class=\"col-6\">\r\n        <p>Материалы: {{Offer.details.material}} ₽</p>\r\n    </div>\r\n    <div class=\"col-6\">\r\n        <p *ngIf='!changeIndicator'>Фонд окон: {{Offer.details.windowFond}} ₽</p>\r\n        <mat-form-field *ngIf='changeIndicator'>\r\n            <input matInput placeholder=\"Фонд окон\" (change)=\"calculate()\" [(ngModel)]='Offer.details.windowFond'>\r\n        </mat-form-field>\r\n    </div>\r\n    <div class=\"col-6\">\r\n        <p *ngIf='!changeIndicator'>Прибыль: {{Offer.details.profit}} ₽</p>\r\n        <mat-form-field *ngIf='changeIndicator'>\r\n            <input matInput placeholder=\"Прибыль\" (change)=\"calculate()\" [(ngModel)]='Offer.details.profit'>\r\n        </mat-form-field>\r\n    </div>\r\n    <div class=\"col-12\">\r\n        <button mat-raised-button color=\"primary\" *ngIf='changeIndicator' (click)='saveOfferDetailChanges()'>Сохранить</button>\r\n    </div>\r\n    <div class=\"col-6\">\r\n        <h4>Итог: {{Offer.details.itog}} ₽</h4>\r\n    </div>\r\n    <div class=\"col-6\">\r\n        <h4>Итог: {{Offer.details.itogMaterial}} ₽</h4>\r\n    </div>\r\n</div>"

/***/ }),

/***/ "./src/app/CRM/auth/login/login.component.html":
/*!*****************************************************!*\
  !*** ./src/app/CRM/auth/login/login.component.html ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<input type=\"email\" [(ngModel)]='User.email' placeholder=\"email\">\n<input type=\"password\" [(ngModel)]='User.password' placeholder=\"pass\">\n<button (click)='login()'>Войти</button>\n<button (click)='register()'>Регистрация</button>\n"

/***/ }),

/***/ "./src/app/CRM/auth/login/login.component.styl":
/*!*****************************************************!*\
  !*** ./src/app/CRM/auth/login/login.component.styl ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/*# sourceMappingURL=src/app/CRM/auth/login/login.component.css.map */\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvQ1JNL2F1dGgvbG9naW4vbG9naW4uY29tcG9uZW50LnN0eWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEscUVBQXFFIiwiZmlsZSI6InNyYy9hcHAvQ1JNL2F1dGgvbG9naW4vbG9naW4uY29tcG9uZW50LnN0eWwifQ== */"

/***/ }),

/***/ "./src/app/CRM/auth/login/login.component.ts":
/*!***************************************************!*\
  !*** ./src/app/CRM/auth/login/login.component.ts ***!
  \***************************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_alert_alert_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/alert/alert.service */ "./src/app/services/alert/alert.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/auth/auth.service */ "./src/app/services/auth/auth.service.ts");





var LoginComponent = /** @class */ (function () {
    function LoginComponent(alert, _routes, auth) {
        this.alert = alert;
        this._routes = _routes;
        this.auth = auth;
        this.User = {};
    }
    LoginComponent.prototype.ngOnInit = function () {
    };
    LoginComponent.prototype.register = function () {
        var _this = this;
        return this.auth.registerNewEmployee(this.User)
            .subscribe(function (data) {
            _this._routes.navigate(['/newlead']);
        }, function (err) {
            _this.alert.openSnackBar(err);
        });
    };
    LoginComponent.prototype.login = function () {
        var _this = this;
        return this.auth.loginByEmployee(this.User)
            .subscribe(function (data) {
            console.log('Переадресую');
            _this._routes.navigate(['/newlead']);
        }, function (err) {
            _this.alert.openSnackBar(err);
        });
    };
    LoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.component.html */ "./src/app/CRM/auth/login/login.component.html"),
            styles: [__webpack_require__(/*! ./login.component.styl */ "./src/app/CRM/auth/login/login.component.styl")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_alert_alert_service__WEBPACK_IMPORTED_MODULE_2__["AlertService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            src_app_services_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]])
    ], LoginComponent);
    return LoginComponent;
}());



/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _CRM_Leads_new_lead_new_lead_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./CRM/Leads/new-lead/new-lead.component */ "./src/app/CRM/Leads/new-lead/new-lead.component.ts");
/* harmony import */ var _CRM_Leads_lead_list_lead_list_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./CRM/Leads/lead-list/lead-list.component */ "./src/app/CRM/Leads/lead-list/lead-list.component.ts");
/* harmony import */ var _CRM_Leads_lead_page_lead_page_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./CRM/Leads/lead-page/lead-page.component */ "./src/app/CRM/Leads/lead-page/lead-page.component.ts");
/* harmony import */ var _CRM_auth_login_login_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./CRM/auth/login/login.component */ "./src/app/CRM/auth/login/login.component.ts");
/* harmony import */ var _services_auth_auth_guard__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./services/auth/auth.guard */ "./src/app/services/auth/auth.guard.ts");








var routes = [
    { path: 'login', component: _CRM_auth_login_login_component__WEBPACK_IMPORTED_MODULE_6__["LoginComponent"] },
    { path: 'newlead', component: _CRM_Leads_new_lead_new_lead_component__WEBPACK_IMPORTED_MODULE_3__["NewLeadComponent"], canActivate: [_services_auth_auth_guard__WEBPACK_IMPORTED_MODULE_7__["AuthGuard"]] },
    { path: 'leadlist', component: _CRM_Leads_lead_list_lead_list_component__WEBPACK_IMPORTED_MODULE_4__["LeadListComponent"], canActivate: [_services_auth_auth_guard__WEBPACK_IMPORTED_MODULE_7__["AuthGuard"]] },
    { path: 'leadlist/:id', component: _CRM_Leads_lead_page_lead_page_component__WEBPACK_IMPORTED_MODULE_5__["LeadPageComponent"], canActivate: [_services_auth_auth_guard__WEBPACK_IMPORTED_MODULE_7__["AuthGuard"]] },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<nav class=\"navbar navbar-dark bg-dark navbar-expand-lg\">\r\n  <a class=\"navbar-brand\" href=\"#\">CleanUp CRM</a>\r\n  <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarText\" aria-controls=\"navbarText\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">\r\n    <span class=\"navbar-toggler-icon\"></span>\r\n  </button>\r\n  <div class=\"collapse navbar-collapse\" id=\"navbarText\">\r\n    <ul class=\"navbar-nav mr-auto\">\r\n\r\n      <!-- <li class=\"nav-item\">\r\n        <a class=\"nav-link\" href=\"#\">Features</a>\r\n      </li> -->\r\n      <li class=\"nav-item dropdown\">\r\n        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"navbarDropdownMenuLink\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">\r\n          CRM\r\n        </a>\r\n        <div class=\"dropdown-menu\" aria-labelledby=\"navbarDropdownMenuLink\">\r\n          <a class=\"dropdown-item\" routerLink=\"/newlead\">Создать лид</a>\r\n          <a class=\"dropdown-item\" routerLink=\"/leadlist\">Список лидов</a>\r\n        </div>\r\n      </li>\r\n    </ul>\r\n    <span class=\"navbar-text\">\r\n      <a href=\"tel:+7(843)207-02-96\">+7 (843) 207-02-96</a>\r\n    </span>\r\n  </div>\r\n</nav>\r\n\r\n<router-outlet></router-outlet>\r\n"

/***/ }),

/***/ "./src/app/app.component.styl":
/*!************************************!*\
  !*** ./src/app/app.component.styl ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/*# sourceMappingURL=src/app/app.component.css.map */\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5zdHlsIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLG9EQUFvRCIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc3R5bCJ9 */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'CleanUpCRM';
    }
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.styl */ "./src/app/app.component.styl")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/esm5/input.es5.js");
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/select */ "./node_modules/@angular/material/esm5/select.es5.js");
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/checkbox */ "./node_modules/@angular/material/esm5/checkbox.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/esm5/button.es5.js");
/* harmony import */ var ng_pick_datetime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ng-pick-datetime */ "./node_modules/ng-pick-datetime/picker.js");
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material/menu */ "./node_modules/@angular/material/esm5/menu.es5.js");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/esm5/table.es5.js");
/* harmony import */ var _angular_material_sort__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material/sort */ "./node_modules/@angular/material/esm5/sort.es5.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_material_chips__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/material/chips */ "./node_modules/@angular/material/esm5/chips.es5.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/material/snack-bar */ "./node_modules/@angular/material/esm5/snack-bar.es5.js");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/material/icon */ "./node_modules/@angular/material/esm5/icon.es5.js");
/* harmony import */ var _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/material/bottom-sheet */ "./node_modules/@angular/material/esm5/bottom-sheet.es5.js");
/* harmony import */ var ngx_cookie_service__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ngx-cookie-service */ "./node_modules/ngx-cookie-service/index.js");
/* harmony import */ var _calculate_b2bregular_b2bregular_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./calculate/b2bregular/b2bregular.component */ "./src/app/calculate/b2bregular/b2bregular.component.ts");
/* harmony import */ var _services_calculate_calculate_service__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./services/calculate/calculate.service */ "./src/app/services/calculate/calculate.service.ts");
/* harmony import */ var _services_HTTP_myhttp_service__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./services/HTTP/myhttp.service */ "./src/app/services/HTTP/myhttp.service.ts");
/* harmony import */ var _CRM_Leads_lead_list_lead_list_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./CRM/Leads/lead-list/lead-list.component */ "./src/app/CRM/Leads/lead-list/lead-list.component.ts");
/* harmony import */ var _CRM_Leads_lead_page_lead_page_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./CRM/Leads/lead-page/lead-page.component */ "./src/app/CRM/Leads/lead-page/lead-page.component.ts");
/* harmony import */ var _CRM_Leads_new_lead_new_lead_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./CRM/Leads/new-lead/new-lead.component */ "./src/app/CRM/Leads/new-lead/new-lead.component.ts");
/* harmony import */ var _filters_pipe__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./filters.pipe */ "./src/app/filters.pipe.ts");
/* harmony import */ var _CRM_Offers_offer_into_lead_offer_into_lead_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./CRM/Offers/offer-into-lead/offer-into-lead.component */ "./src/app/CRM/Offers/offer-into-lead/offer-into-lead.component.ts");
/* harmony import */ var _services_alert_alert_service__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./services/alert/alert.service */ "./src/app/services/alert/alert.service.ts");
/* harmony import */ var _CRM_auth_login_login_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./CRM/auth/login/login.component */ "./src/app/CRM/auth/login/login.component.ts");
/* harmony import */ var _services_auth_auth_guard__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./services/auth/auth.guard */ "./src/app/services/auth/auth.guard.ts");


































var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"],
                _calculate_b2bregular_b2bregular_component__WEBPACK_IMPORTED_MODULE_23__["B2bregularComponent"],
                _CRM_Leads_lead_list_lead_list_component__WEBPACK_IMPORTED_MODULE_26__["LeadListComponent"],
                _CRM_Leads_lead_page_lead_page_component__WEBPACK_IMPORTED_MODULE_27__["LeadPageComponent"],
                _CRM_Leads_new_lead_new_lead_component__WEBPACK_IMPORTED_MODULE_28__["NewLeadComponent"],
                _filters_pipe__WEBPACK_IMPORTED_MODULE_29__["FiltersPipeCustom"],
                _CRM_Offers_offer_into_lead_offer_into_lead_component__WEBPACK_IMPORTED_MODULE_30__["OfferIntoLeadComponent"],
                _services_alert_alert_service__WEBPACK_IMPORTED_MODULE_31__["AlertComponent"],
                _CRM_Offers_offer_into_lead_offer_into_lead_component__WEBPACK_IMPORTED_MODULE_30__["BottomSheet"],
                _CRM_auth_login_login_component__WEBPACK_IMPORTED_MODULE_32__["LoginComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_3__["AppRoutingModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__["BrowserAnimationsModule"],
                _angular_material_input__WEBPACK_IMPORTED_MODULE_7__["MatInputModule"],
                _angular_material_select__WEBPACK_IMPORTED_MODULE_8__["MatSelectModule"],
                _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_9__["MatCheckboxModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_10__["FormsModule"],
                ng_pick_datetime__WEBPACK_IMPORTED_MODULE_12__["OwlDateTimeModule"],
                ng_pick_datetime__WEBPACK_IMPORTED_MODULE_12__["OwlNativeDateTimeModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ReactiveFormsModule"],
                _angular_material_button__WEBPACK_IMPORTED_MODULE_11__["MatButtonModule"],
                _angular_material_menu__WEBPACK_IMPORTED_MODULE_13__["MatMenuModule"],
                _angular_material_table__WEBPACK_IMPORTED_MODULE_14__["MatTableModule"],
                _angular_material_sort__WEBPACK_IMPORTED_MODULE_15__["MatSortModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_16__["MatPaginatorModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_16__["MatFormFieldModule"],
                _angular_material_chips__WEBPACK_IMPORTED_MODULE_17__["MatChipsModule"],
                _angular_material_dialog__WEBPACK_IMPORTED_MODULE_18__["MatDialogModule"],
                _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_19__["MatSnackBarModule"],
                _angular_material_icon__WEBPACK_IMPORTED_MODULE_20__["MatIconModule"],
                _angular_material_bottom_sheet__WEBPACK_IMPORTED_MODULE_21__["MatBottomSheetModule"],
            ],
            entryComponents: [_CRM_Offers_offer_into_lead_offer_into_lead_component__WEBPACK_IMPORTED_MODULE_30__["OfferIntoLeadComponent"], _services_alert_alert_service__WEBPACK_IMPORTED_MODULE_31__["AlertComponent"], _CRM_Offers_offer_into_lead_offer_into_lead_component__WEBPACK_IMPORTED_MODULE_30__["BottomSheet"]],
            providers: [
                _services_calculate_calculate_service__WEBPACK_IMPORTED_MODULE_24__["CalculateService"],
                _services_HTTP_myhttp_service__WEBPACK_IMPORTED_MODULE_25__["myHTTPService"],
                { provide: ng_pick_datetime__WEBPACK_IMPORTED_MODULE_12__["OWL_DATE_TIME_LOCALE"], useValue: 'ru' },
                _services_auth_auth_guard__WEBPACK_IMPORTED_MODULE_33__["AuthGuard"],
                ngx_cookie_service__WEBPACK_IMPORTED_MODULE_22__["CookieService"]
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/calculate/b2bregular/b2bregular.component.html":
/*!****************************************************************!*\
  !*** ./src/app/calculate/b2bregular/b2bregular.component.html ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/calculate/b2bregular/b2bregular.component.styl":
/*!****************************************************************!*\
  !*** ./src/app/calculate/b2bregular/b2bregular.component.styl ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/*# sourceMappingURL=src/app/calculate/b2bregular/b2bregular.component.css.map */\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2FsY3VsYXRlL2IyYnJlZ3VsYXIvYjJicmVndWxhci5jb21wb25lbnQuc3R5bCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxnRkFBZ0YiLCJmaWxlIjoic3JjL2FwcC9jYWxjdWxhdGUvYjJicmVndWxhci9iMmJyZWd1bGFyLmNvbXBvbmVudC5zdHlsIn0= */"

/***/ }),

/***/ "./src/app/calculate/b2bregular/b2bregular.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/calculate/b2bregular/b2bregular.component.ts ***!
  \**************************************************************/
/*! exports provided: B2bregularComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "B2bregularComponent", function() { return B2bregularComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var B2bregularComponent = /** @class */ (function () {
    function B2bregularComponent() {
    }
    B2bregularComponent.prototype.ngOnInit = function () {
    };
    B2bregularComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-b2bregular',
            template: __webpack_require__(/*! ./b2bregular.component.html */ "./src/app/calculate/b2bregular/b2bregular.component.html"),
            styles: [__webpack_require__(/*! ./b2bregular.component.styl */ "./src/app/calculate/b2bregular/b2bregular.component.styl")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], B2bregularComponent);
    return B2bregularComponent;
}());



/***/ }),

/***/ "./src/app/filters.pipe.ts":
/*!*********************************!*\
  !*** ./src/app/filters.pipe.ts ***!
  \*********************************/
/*! exports provided: FiltersPipeCustom */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FiltersPipeCustom", function() { return FiltersPipeCustom; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


/*
 * Raise the value exponentially
 * Takes an exponent argument that defaults to 1.
 * Usage:
 *   value | exponentialStrength:exponent
 * Example:
 *   {{ 2 | exponentialStrength:10 }}
 *   formats to: 1024
*/
var FiltersPipeCustom = /** @class */ (function () {
    function FiltersPipeCustom() {
    }
    FiltersPipeCustom.prototype.transform = function (tasks) {
        console.log(tasks);
        return tasks.sort(function (a, b) {
            return a.createdDate - b.createdDate;
        });
    };
    FiltersPipeCustom = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'tasks'
        })
    ], FiltersPipeCustom);
    return FiltersPipeCustom;
}());



/***/ }),

/***/ "./src/app/services/HTTP/myhttp.service.ts":
/*!*************************************************!*\
  !*** ./src/app/services/HTTP/myhttp.service.ts ***!
  \*************************************************/
/*! exports provided: myHTTPService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "myHTTPService", function() { return myHTTPService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");



var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
        'Content-Type': 'application/json',
        'Authorization': 'my-auth-token'
    }), withCredentials: true
};
var myHTTPService = /** @class */ (function () {
    function myHTTPService(http) {
        this.http = http;
    }
    myHTTPService.prototype.postHTTP = function (url, info) {
        return this.http.post(url, info, { withCredentials: true });
    };
    myHTTPService.prototype.getHTTP = function (url) {
        return this.http.get(url, { withCredentials: true });
    };
    myHTTPService.prototype.putHTTP = function (url, info) {
        return this.http.put(url, info, { withCredentials: true });
    };
    myHTTPService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], myHTTPService);
    return myHTTPService;
}());



/***/ }),

/***/ "./src/app/services/alert/alert.service.ts":
/*!*************************************************!*\
  !*** ./src/app/services/alert/alert.service.ts ***!
  \*************************************************/
/*! exports provided: AlertService, AlertComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AlertService", function() { return AlertService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AlertComponent", function() { return AlertComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");



var AlertService = /** @class */ (function () {
    function AlertService(snackBar) {
        this.snackBar = snackBar;
    }
    AlertService.prototype.openSnackBar = function (newData) {
        this.snackBar.openFromComponent(AlertComponent, {
            duration: 2000,
            data: newData
        });
    };
    ;
    AlertService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSnackBar"]])
    ], AlertService);
    return AlertService;
}());

var AlertComponent = /** @class */ (function () {
    function AlertComponent(data) {
        this.data = data;
    }
    AlertComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'snack-bar',
            template: '<span class="alert">{{data}}</span>',
            styles: ["\n    .alert {\n      color: hotpink;\n    }\n  "]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_material__WEBPACK_IMPORTED_MODULE_2__["MAT_SNACK_BAR_DATA"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object])
    ], AlertComponent);
    return AlertComponent;
}());



/***/ }),

/***/ "./src/app/services/auth/auth.guard.ts":
/*!*********************************************!*\
  !*** ./src/app/services/auth/auth.guard.ts ***!
  \*********************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var ngx_cookie_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-cookie-service */ "./node_modules/ngx-cookie-service/index.js");
/* harmony import */ var _HTTP_myhttp_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../HTTP/myhttp.service */ "./src/app/services/HTTP/myhttp.service.ts");
/* harmony import */ var rxjs_internal_Observable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/internal/Observable */ "./node_modules/rxjs/internal/Observable.js");
/* harmony import */ var rxjs_internal_Observable__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(rxjs_internal_Observable__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");







var AuthGuard = /** @class */ (function () {
    function AuthGuard(_router, cookieService, myHttp) {
        this._router = _router;
        this.cookieService = cookieService;
        this.myHttp = myHttp;
    }
    AuthGuard.prototype.canActivate = function () {
        var _this = this;
        return this.myHttp.getHTTP('http://localhost:3000/detect')
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["map"])(function (data) {
            if (data.detect === true) {
                return true;
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["catchError"])(function (err) {
            _this._router.navigate(['/login']);
            return rxjs_internal_Observable__WEBPACK_IMPORTED_MODULE_5__["Observable"].throw(err.statusText);
        }));
    };
    AuthGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            ngx_cookie_service__WEBPACK_IMPORTED_MODULE_3__["CookieService"],
            _HTTP_myhttp_service__WEBPACK_IMPORTED_MODULE_4__["myHTTPService"]])
    ], AuthGuard);
    return AuthGuard;
}());



/***/ }),

/***/ "./src/app/services/auth/auth.service.ts":
/*!***********************************************!*\
  !*** ./src/app/services/auth/auth.service.ts ***!
  \***********************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _HTTP_myhttp_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../HTTP/myhttp.service */ "./src/app/services/HTTP/myhttp.service.ts");



var AuthService = /** @class */ (function () {
    function AuthService(myHttp) {
        this.myHttp = myHttp;
    }
    AuthService.prototype.registerNewEmployee = function (employee) {
        return this.myHttp.postHTTP('http://localhost:3000/register', employee);
    };
    AuthService.prototype.loginByEmployee = function (employee) {
        return this.myHttp.postHTTP('http://localhost:3000/login', employee);
    };
    AuthService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_HTTP_myhttp_service__WEBPACK_IMPORTED_MODULE_2__["myHTTPService"]])
    ], AuthService);
    return AuthService;
}());



/***/ }),

/***/ "./src/app/services/calculate/calculate.service.ts":
/*!*********************************************************!*\
  !*** ./src/app/services/calculate/calculate.service.ts ***!
  \*********************************************************/
/*! exports provided: CalculateService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CalculateService", function() { return CalculateService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var CalculateService = /** @class */ (function () {
    function CalculateService() {
        this.ONE_HOUR_PRICE = 59;
        this.ONE_METER_PRICE = 0.455;
        this.ONE_DAY_PRICE = 227;
    }
    CalculateService.prototype.calculateFot = function (area, regularValue, timeValue, twice) {
        if (timeValue != '' && timeValue != null) { // Считается по часам
            console.log('Считается по часам');
            return this.beautyPrice(regularValue * (this.ONE_DAY_PRICE + timeValue * this.ONE_HOUR_PRICE));
        }
        else { //Считаем по квадратуре
            if (twice === true) {
                return this.beautyPrice(regularValue * (this.ONE_DAY_PRICE + area * this.ONE_METER_PRICE * 2) + 2000);
            }
            return this.beautyPrice(regularValue * (this.ONE_DAY_PRICE + area * this.ONE_METER_PRICE));
        }
    };
    CalculateService.prototype.calculateManagerWage = function (area, regularValue) {
        if (area < 120 && regularValue < 9) {
            return 750;
        }
        return 500 + 750;
    };
    CalculateService.prototype.calculateWindowsFond = function (area) {
        return 300;
    };
    CalculateService.prototype.calculateTinkoffCommission = function (area, regularValue, timeValue, twice) {
        return this.beautyPrice((this.calculateFot(area, regularValue, timeValue, twice)
            + this.calculateManagerWage(area, regularValue)
            + this.calculateWindowsFond(area)) * 1.5 / 98.5);
    };
    CalculateService.prototype.beautyPrice = function (num) {
        Number.parseInt(num);
        return Math.ceil(num);
    };
    CalculateService.prototype.calculateMaterial = function (area, regularValue, twice) {
        if (twice === true) {
            return this.beautyPrice((4.08 * regularValue + regularValue * area * 0.09 * 2 + 718));
        }
        return this.beautyPrice((4.08 * regularValue + regularValue * area * 0.09 + 718));
    };
    CalculateService.prototype.setProfit = function (area, regularValue, timeValue, twice) {
        if (isNaN(timeValue) && (area <= 120) && (regularValue < 9)) {
            return 1000;
        }
        if ((isNaN(timeValue) || timeValue === '') && (area <= 120) && regularValue < 9) {
            return 1500;
        }
        return 3000;
    };
    CalculateService.prototype.calculateItog = function (area, regularValue, timeValue, twice) {
        return this.beautyPrice((this.calculateFot(area, regularValue, timeValue, twice)
            + this.calculateManagerWage(area, regularValue)
            + this.calculateTinkoffCommission(area, regularValue, timeValue, twice)
            + this.calculateWindowsFond(area)
            + this.setProfit(area, regularValue, timeValue, twice)) * 100 / 94);
    };
    CalculateService.prototype.calculateItogMaterial = function (area, regularValue, timeValue, twice) {
        return this.beautyPrice((this.calculateFot(area, regularValue, timeValue, twice)
            + this.calculateManagerWage(area, regularValue)
            + this.calculateTinkoffCommission(area, regularValue, timeValue, twice)
            + this.calculateWindowsFond(area)
            + this.calculateMaterial(area, regularValue, twice)
            + this.setProfit(area, regularValue, timeValue, twice)) * 100 / 94);
    };
    CalculateService.prototype.getCalculate = function (area, regularValue, timeValue, twice) {
        var Offer = {
            fot: this.calculateFot(area, regularValue, timeValue, twice),
            managerWage: this.calculateManagerWage(area, regularValue),
            tinkoffCommission: this.calculateTinkoffCommission(area, regularValue, timeValue, twice),
            windowFond: this.calculateWindowsFond(area),
            material: this.calculateMaterial(area, regularValue, twice),
            profit: this.setProfit(area, regularValue, timeValue, twice),
            itog: this.calculateItog(area, regularValue, timeValue, twice),
            itogMaterial: this.calculateItogMaterial(area, regularValue, timeValue, twice)
        };
        return Offer;
    };
    CalculateService.prototype.getChangesCalculate = function (Offer) {
        var rashodi = Number.parseInt(Offer.details.fot)
            + Number.parseInt(Offer.details.managerWage)
            + Number.parseInt(Offer.details.windowFond);
        var tinkoff = rashodi * 1.5 / 98.5;
        var profit = Number.parseInt(Offer.details.profit), material = Number.parseInt(Offer.details.material);
        return {
            tinkoffCommission: this.beautyPrice(tinkoff),
            itog: this.beautyPrice((rashodi + tinkoff + profit) * 100 / 94),
            itogMaterial: this.beautyPrice((rashodi + tinkoff + profit + material) * 100 / 94)
        };
    };
    CalculateService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], CalculateService);
    return CalculateService;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! E:\Projects\cleanup_crm\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map